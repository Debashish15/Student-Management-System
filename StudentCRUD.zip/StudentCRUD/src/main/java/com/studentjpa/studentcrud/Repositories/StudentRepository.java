package com.studentjpa.studentcrud.Repositories;


import com.studentjpa.studentcrud.Entities.user;
import org.springframework.data.repository.CrudRepository;

public interface StudentRepository extends CrudRepository<user, Long> {

}
