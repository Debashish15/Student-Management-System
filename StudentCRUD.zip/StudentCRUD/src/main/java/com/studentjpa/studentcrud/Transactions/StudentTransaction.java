package com.studentjpa.studentcrud.Transactions;

import com.studentjpa.studentcrud.Entities.user;
import com.studentjpa.studentcrud.Repositories.StudentRepository;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Locale;
import java.util.Scanner;

@Service
public class StudentTransaction {

    Scanner sc = new Scanner(System.in);

    private final StudentRepository Repo;

    public StudentTransaction(StudentRepository repo) {
        Repo = repo;
    }


    @Transactional
    public void addDetails(){
        System.out.println("Enter Details of Student");

        System.out.print("Enter your Name: ");
        String name = sc.nextLine();

        System.out.print("Enter Your Email Id : ");
        String email = sc.nextLine();

        System.out.print("Enter your Password: ");
        String password = sc.nextLine();

        System.out.print("Enter your state : ");
        String state = sc.nextLine();

        user studentDetails = user.builder()
                .name(name)
                .email(email)
                .password(password)
                .state(state)
                .build();

        Repo.save(studentDetails);
        System.out.println("Details added successfully....");
    }


}
