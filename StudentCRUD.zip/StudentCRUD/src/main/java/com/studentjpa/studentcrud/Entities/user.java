package com.studentjpa.studentcrud.Entities;

import jakarta.persistence.*;
import lombok.*;

@Table(name="student")
@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class user {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id ;

   @Column(name = "name")
    private String name ;

   @Column(name = "email")
   private String email;

    @Column(name = "password")
    private String password;

    @Column(name = "state")
   private String state;
}
